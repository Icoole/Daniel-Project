要掌握，先拆解。
# Navy Federal Credit Union - Technical Specification

## 1. Tech Stack Overview

| Category | Technology |
|----------|------------|
| Framework | React 18 + TypeScript |
| Build Tool | Vite |
| Styling | Tailwind CSS 3.4 |
| UI Components | shadcn/ui |
| Animation | Framer Motion |
| Icons | Lucide React |
| Routing | React Router DOM |
| State Management | React Context (for nav state) |

## 2. Tailwind Configuration Guide

### Colors Extension
```javascript
colors: {
  navy: {
    DEFAULT: '#0A3D62',
    dark: '#082F4D',
    light: '#0E4B7A',
  },
  orange: {
    DEFAULT: '#E87722',
    dark: '#D06A1F',
    light: '#F08A3D',
  },
  cream: '#FFF8E7',
  link: '#0073B9',
}
```

### Font Extension
```javascript
fontFamily: {
  sans: ['Source Sans Pro', 'system-ui', 'sans-serif'],
}
```

## 3. Component Inventory

### Shadcn/UI Components (Pre-installed)
- Button
- Card
- Dialog
- Dropdown Menu
- Navigation Menu
- Sheet (mobile menu)
- Accordion
- Tabs

### Custom Components

#### Layout Components
| Component | Props | Description |
|-----------|-------|-------------|
| `Navbar` | - | Main navigation with mega menus |
| `Footer` | - | Site footer with links |
| `AlertBanner` | `message: string, link?: string` | Dismissible alert |
| `Container` | `children, className?` | Max-width wrapper |
| `Section` | `children, className?, bg?` | Page section wrapper |

#### Navigation Components
| Component | Props | Description |
|-----------|-------|-------------|
| `MegaMenu` | `items: MenuItem[]` | Dropdown mega menu |
| `MobileMenu` | `isOpen, onClose` | Mobile navigation drawer |
| `NavLink` | `to, children, dropdown?` | Navigation link |

#### Section Components
| Component | Props | Description |
|-----------|-------|-------------|
| `HeroSection` | `title, cta, image` | Homepage hero |
| `ProductGrid` | `products: Product[]` | Product category cards |
| `FeatureSection` | `title, content, image, reversed?` | Two-column feature |
| `PromoCards` | `cards: PromoCard[]` | Promotional cards grid |
| `MembershipCTA` | - | Membership section |
| `ArticleGrid` | `articles: Article[]` | Resource articles |
| `SpotlightSection` | `story: SpotlightStory` | Veteran spotlight |

#### UI Components
| Component | Props | Description |
|-----------|-------|-------------|
| `ProductCard` | `icon, title, href` | Product category card |
| `PromoCard` | `title, cta, bgImage` | Promotional card |
| `ArticleCard` | `title, description, href` | Resource article card |
| `IconBox` | `icon, size, className` | Icon wrapper |

## 4. Animation Implementation Plan

| Interaction Name | Tech Choice | Implementation Logic |
|------------------|-------------|---------------------|
| Page Load Fade | Framer Motion | `initial={{ opacity: 0 }}` `animate={{ opacity: 1 }}` duration 0.4s |
| Hero Text Stagger | Framer Motion | `staggerChildren: 0.1` on container, `y: 20 -> 0` on items |
| Scroll Reveal | Framer Motion | `whileInView` with `viewport={{ once: true, amount: 0.2 }}` |
| Card Hover Lift | Tailwind + FM | `whileHover={{ y: -4 }}` transition 0.3s |
| Button Hover | Tailwind | `hover:scale-[1.02]` `transition-all duration-200` |
| Link Underline | CSS | `after:` pseudo-element, `scaleX(0) -> scaleX(1)` on hover |
| Nav Dropdown | Framer Motion | `AnimatePresence` with fade + translateY |
| Arrow Icon | Tailwind | `group-hover:translate-x-1 transition-transform` |
| Scroll to Top | Framer Motion | `animate={{ opacity: isVisible ? 1 : 0 }}` |
| Image Parallax | Framer Motion | `useScroll` + `useTransform` for subtle Y movement |

### Animation Constants
```typescript
export const ANIMATION = {
  duration: {
    fast: 0.2,
    normal: 0.3,
    slow: 0.6,
  },
  easing: {
    default: [0.4, 0, 0.2, 1],
    bounce: [0.68, -0.55, 0.265, 1.55],
  },
  stagger: {
    fast: 0.05,
    normal: 0.1,
    slow: 0.15,
  },
};
```

## 5. Project File Structure

```
/mnt/okcomputer/output/app/
├── public/
│   └── images/
│       ├── hero/
│       ├── products/
│       ├── promotions/
│       └── stories/
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.tsx
│   │   │   ├── Footer.tsx
│   │   │   ├── AlertBanner.tsx
│   │   │   └── Container.tsx
│   │   ├── navigation/
│   │   │   ├── MegaMenu.tsx
│   │   │   ├── MobileMenu.tsx
│   │   │   └── NavLink.tsx
│   │   ├── ui/
│   │   │   ├── ProductCard.tsx
│   │   │   ├── PromoCard.tsx
│   │   │   ├── ArticleCard.tsx
│   │   │   └── IconBox.tsx
│   │   └── sections/
│   │       ├── HeroSection.tsx
│   │       ├── ProductGrid.tsx
│   │       ├── FeatureSection.tsx
│   │       ├── PromoCards.tsx
│   │       ├── MembershipCTA.tsx
│   │       ├── ArticleGrid.tsx
│   │       └── SpotlightSection.tsx
│   ├── hooks/
│   │   ├── useScrollPosition.ts
│   │   └── useMediaQuery.ts
│   ├── lib/
│   │   ├── utils.ts
│   │   └── animations.ts
│   ├── data/
│   │   ├── navigation.ts
│   │   ├── products.ts
│   │   └── content.ts
│   ├── pages/
│   │   ├── Home.tsx
│   │   ├── CheckingSavings.tsx
│   │   ├── CreditCards.tsx
│   │   ├── AutoLoans.tsx
│   │   ├── Membership.tsx
│   │   └── About.tsx
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── index.html
├── tailwind.config.js
├── vite.config.ts
└── package.json
```

## 6. Package Installation List

```bash
# Initialize project (already done by init script)
# bash scripts/init-webapp.sh "Navy Federal Credit Union"

# Animation library
npm install framer-motion

# Icons
npm install lucide-react

# Routing
npm install react-router-dom

# Utilities
npm install clsx tailwind-merge
```

## 7. Responsive Breakpoints

| Breakpoint | Width | Layout Changes |
|------------|-------|----------------|
| Mobile | < 640px | Single column, hamburger menu |
| Tablet | 640-1024px | 2-column grids, condensed nav |
| Desktop | > 1024px | Full layout, mega menus |

## 8. Key Implementation Notes

1. **Navigation**: Use React Context for mobile menu state
2. **Mega Menus**: Implement with absolute positioning, z-index layering
3. **Scroll Animations**: Use Framer Motion's `whileInView` for performance
4. **Images**: Use WebP format with fallbacks, lazy loading
5. **Accessibility**: Ensure keyboard navigation, ARIA labels, focus states
6. **Performance**: Use `will-change` sparingly, prefer `transform` animations
